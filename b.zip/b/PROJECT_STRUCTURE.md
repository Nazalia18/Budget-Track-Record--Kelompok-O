# 📦 Project Structure & File Manifest

## Complete Project Tree

```
budget-app/
│
├── 📄 README.md                          # Main documentation
├── 📄 QUICKSTART.md                      # Quick start guide (5 menit setup)
├── 📄 FEATURES.md                        # Feature checklist & roadmap
├── 📄 API_REFERENCE.md                   # Backend API documentation
├── 📄 .gitignore                         # Git ignore rules
│
├── 📁 frontend/                          # Frontend files
│   ├── index.html                        # Login page
│   ├── dashboard.html                    # Main dashboard & app
│   │
│   └── 📁 assets/
│       ├── 📁 css/
│       │   └── styles.css                # All styling (responsive)
│       │
│       └── 📁 js/
│           ├── auth.js                   # Authentication logic
│           ├── app.js                    # Main dashboard logic & BudgetApp class
│           ├── dashboard.js              # Module coordinator
│           ├── savings.js                # Savings management & SavingsManager
│           └── analytics.js              # Charts & analytics & AnalyticsManager
│
└── 📁 backend/                           # Backend files
    ├── app.py                            # Flask server
    └── requirements.txt                  # Python dependencies

```

---

## 📋 File Checklist

### Frontend Files
- [x] `frontend/index.html` - Login page (HTML)
- [x] `frontend/dashboard.html` - Main app (HTML)
- [x] `frontend/assets/css/styles.css` - Styling (CSS)
- [x] `frontend/assets/js/auth.js` - Auth logic (JavaScript)
- [x] `frontend/assets/js/app.js` - Dashboard logic (JavaScript)
- [x] `frontend/assets/js/dashboard.js` - Module coordinator (JavaScript)
- [x] `frontend/assets/js/savings.js` - Savings logic (JavaScript)
- [x] `frontend/assets/js/analytics.js` - Charts logic (JavaScript)

### Backend Files
- [x] `backend/app.py` - Flask server
- [x] `backend/requirements.txt` - Dependencies

### Documentation Files
- [x] `README.md` - Main documentation
- [x] `QUICKSTART.md` - Quick start guide
- [x] `FEATURES.md` - Feature documentation
- [x] `API_REFERENCE.md` - API documentation
- [x] `.gitignore` - Git ignore rules
- [x] `PROJECT_STRUCTURE.md` - This file

---

## 📊 File Sizes & Statistics

### HTML Files
| File | Purpose | Size |
|------|---------|------|
| index.html | Login page | ~3KB |
| dashboard.html | Main app | ~12KB |
| **Total** | - | **~15KB** |

### CSS Files
| File | Purpose | Lines | Size |
|------|---------|-------|------|
| styles.css | All styling | ~800 | ~28KB |

### JavaScript Files
| File | Purpose | Lines | Classes | Size |
|------|---------|-------|---------|------|
| auth.js | Authentication | ~150 | 1 (AuthManager) | ~5KB |
| app.js | Main dashboard | ~450 | 1 (BudgetApp) | ~18KB |
| dashboard.js | Coordinator | ~30 | 0 | ~1KB |
| savings.js | Savings mgmt | ~350 | 1 (SavingsManager) | ~13KB |
| analytics.js | Analytics | ~200 | 1 (AnalyticsManager) | ~8KB |
| **Total** | - | **~1180** | **4** | **~45KB** |

### Python Files
| File | Purpose | Lines | Size |
|------|---------|-------|------|
| app.py | Flask server | ~50 | ~1.5KB |
| requirements.txt | Dependencies | ~3 | ~0.1KB |
| **Total** | - | **~53** | **~1.6KB** |

### Total Project Size
- **Frontend:** ~88KB (uncompressed)
- **Backend:** ~1.6KB
- **Documentation:** ~40KB
- **Total:** ~130KB

---

## 🔗 Dependencies & Imports

### JavaScript Dependencies
- **Chart.js** (CDN) - Pie chart visualization
  - URL: `https://cdn.jsdelivr.net/npm/chart.js`
  - Used in: `dashboard.html`, `analytics.js`

### Python Dependencies
- **Flask** 2.3.2 - Web framework
- **flask-cors** 4.0.0 - CORS support
- **Werkzeug** 2.3.6 - WSGI utility library

### Browser APIs Used
- **Local Storage** - Data persistence
- **Fetch API** - HTTP requests (future)
- **Date API** - Date handling
- **JSON** - Data serialization

---

## 🏗️ Architecture Overview

```
┌─────────────────────────────────────────────────┐
│           Browser (Frontend)                    │
│  ┌──────────────────────────────────────────┐   │
│  │  index.html (Login)                      │   │
│  │  - Form login & signup modal             │   │
│  │  - auth.js untuk handle login/register   │   │
│  └──────────────────────────────────────────┘   │
│                     ↓                            │
│  ┌──────────────────────────────────────────┐   │
│  │  dashboard.html (Main App)               │   │
│  │  ┌────────────────────────────────────┐  │   │
│  │  │  CSS: styles.css                   │  │   │
│  │  │  - Responsive grid layout          │  │   │
│  │  │  - Color scheme & typography       │  │   │
│  │  └────────────────────────────────────┘  │   │
│  │  ┌────────────────────────────────────┐  │   │
│  │  │  JavaScript Modules                │  │   │
│  │  │  ┌──────────────────────────────┐  │  │   │
│  │  │  │ app.js (BudgetApp)           │  │  │   │
│  │  │  │ - Dashboard logic            │  │  │   │
│  │  │  │ - KPI calculations           │  │  │   │
│  │  │  │ - Income/Expense management  │  │  │   │
│  │  │  └──────────────────────────────┘  │  │   │
│  │  │  ┌──────────────────────────────┐  │  │   │
│  │  │  │ savings.js (SavingsManager)  │  │  │   │
│  │  │  │ - Savings CRUD               │  │  │   │
│  │  │  │ - Target calculation         │  │  │   │
│  │  │  └──────────────────────────────┘  │  │   │
│  │  │  ┌──────────────────────────────┐  │  │   │
│  │  │  │ analytics.js (Analytics)     │  │  │   │
│  │  │  │ - Pie chart rendering        │  │  │   │
│  │  │  │ - Statistics calculation     │  │  │   │
│  │  │  └──────────────────────────────┘  │  │   │
│  │  │  ┌──────────────────────────────┐  │  │   │
│  │  │  │ dashboard.js (Coordinator)   │  │  │   │
│  │  │  │ - Module initialization      │  │  │   │
│  │  │  │ - Module communication       │  │  │   │
│  │  │  └──────────────────────────────┘  │  │   │
│  │  └────────────────────────────────────┘  │   │
│  │  ┌────────────────────────────────────┐  │   │
│  │  │  Local Storage                     │  │   │
│  │  │  - budget_app_users               │  │   │
│  │  │  - budget_app_[username]          │  │   │
│  │  │  - budget_app_current_user        │  │   │
│  │  └────────────────────────────────────┘  │   │
│  └──────────────────────────────────────────┘   │
└─────────────────────────────────────────────────┘
                     ↓ (HTTP GET/POST)
┌─────────────────────────────────────────────────┐
│           Backend (Python Flask)                │
│  ┌──────────────────────────────────────────┐   │
│  │  app.py                                  │   │
│  │  - Serve index.html (GET /)             │   │
│  │  - Serve dashboard.html                 │   │
│  │  - Health endpoint                      │   │
│  │  - Info endpoint                        │   │
│  │  - CORS enabled                         │   │
│  └──────────────────────────────────────────┘   │
│                                                 │
│  Port: 5000                                     │
│  Debug: True (development)                      │
└─────────────────────────────────────────────────┘
```

---

## 🔄 Data Flow

### Income Setup Flow
```
User Input (Frontend)
  ↓
incomeForm.submit
  ↓
BudgetApp.handleIncomeSubmit()
  ↓
Auto-calculate:
  - Emergency Fund (10%)
  - Daily Limit ((income - emergency) ÷ 30)
  ↓
Save to Local Storage
  ↓
updateDisplay() → Update KPI Cards
```

### Expense Input Flow
```
User Input (Frontend)
  ↓
expenseForm.submit
  ↓
BudgetApp.handleExpenseSubmit()
  ↓
Validate input
  ↓
Save to Local Storage
  ↓
updateDisplay() → Update KPI Cards
  ↓
renderExpenseTable() → Update table
  ↓
checkDailyLimit() → Alert if exceeded
```

### Savings Creation Flow
```
User Input (Frontend)
  ↓
savingsForm.submit
  ↓
SavingsManager.handleSavingsSubmit()
  ↓
Auto-calculate:
  - Daily Amount (target ÷ duration)
  - Target Date
  ↓
Save to Local Storage
  ↓
renderSavingsCards() → Display cards
  ↓
renderSavingsSelect() → Update dropdown
```

### Analytics Rendering Flow
```
Page: Analytics requested
  ↓
AnalyticsManager.renderChart()
  ↓
Calculate expenses by category
  ↓
Prepare Chart.js data
  ↓
Destroy old chart (if exists)
  ↓
Create new chart
  ↓
renderCategoryStats() → Display breakdown
  ↓
renderSavingsStats() → Display stats
```

---

## 🔐 Security Architecture

### Authentication
```
Register:
  Username → Validate unique → Hash password → Store

Login:
  Username → Find → Hash input password → Compare
  Match → Create session → Redirect to dashboard

Logout:
  Clear session → Redirect to login
```

### Data Isolation
```
Each User:
  - Separate Local Storage key: budget_app_[username]
  - Cannot access other user's data
  - Session-based access control
```

### Data Storage
```
Local Storage Schema:
- budget_app_users: { [username]: { password, createdAt } }
- budget_app_[username]: {
    income: { [month]: { amount, date, ... } },
    expenses: [ { id, amount, category, date, ... } ],
    savings: [ { id, name, target, current, transactions, ... } ]
  }
- budget_app_current_user: { username, loginTime }
```

---

## 📈 Scalability Considerations

### Current Limitations
- Local Storage limit: ~5-10MB per domain
- No real-time sync
- No multi-device sync
- No real database

### To Scale:
1. Move to proper database (PostgreSQL/MongoDB)
2. Implement REST API for all operations
3. Add JWT authentication
4. Implement caching layer (Redis)
5. Add API gateway
6. Microservices architecture (future)

---

## 🧪 Testing Coverage

### Unit Tests (Planned)
- [ ] AuthManager.register()
- [ ] AuthManager.login()
- [ ] BudgetApp calculations
- [ ] SavingsManager calculations

### Integration Tests (Planned)
- [ ] Login flow
- [ ] Income setup flow
- [ ] Expense creation flow
- [ ] Data persistence

### E2E Tests (Planned)
- [ ] Complete user journey
- [ ] Multi-user scenarios
- [ ] Data export

---

## 📦 Deployment Checklist

### Pre-deployment
- [ ] All files present and verified
- [ ] No console errors in DevTools
- [ ] All features tested locally
- [ ] Documentation complete
- [ ] .gitignore configured

### Deployment Steps
1. Setup hosting (Vercel/Netlify for frontend)
2. Deploy frontend
3. Setup backend server (Heroku/Railway)
4. Deploy backend
5. Configure domain & SSL
6. Setup monitoring & logging

### Post-deployment
- [ ] Health checks passing
- [ ] All features working
- [ ] Performance acceptable
- [ ] Security reviewed
- [ ] Monitoring active

---

## 🚀 Quick Reference Commands

### Development
```bash
# Start backend
cd backend
python app.py

# Access application
http://localhost:5000

# Open frontend directly
open frontend/index.html
```

### Testing
```bash
# Check health
curl http://localhost:5000/api/health

# Check info
curl http://localhost:5000/api/info
```

### Production
```bash
# Install production dependencies
pip install -r backend/requirements.txt

# Run with production server
gunicorn app:app

# Set environment
export FLASK_ENV=production
```

---

**Last Updated:** Juni 2026
**Maintained By:** Kelompok O - PROKOM
