# 🔌 API Reference - Budget App Backend

## Overview

Backend Budget App berjalan di Flask dan menyediakan basic HTTP endpoints. Saat ini mayoritas logic ada di frontend dengan Local Storage.

**Base URL:** `http://localhost:5000`

---

## Endpoints

### 1. Health Check

#### Request
```
GET /api/health
```

#### Response (200 OK)
```json
{
  "status": "ok",
  "message": "Budget App Server is running",
  "timestamp": "2026-06-11T10:30:45.123456"
}
```

#### Usage
```bash
curl http://localhost:5000/api/health
```

---

### 2. App Info

#### Request
```
GET /api/info
```

#### Response (200 OK)
```json
{
  "app_name": "Budget App",
  "version": "1.0.0",
  "description": "Aplikasi Pengatur Uang Bulanan",
  "features": [
    "User Authentication",
    "Income Management",
    "Expense Tracking",
    "Savings Planning",
    "Expense Analytics"
  ]
}
```

#### Usage
```bash
curl http://localhost:5000/api/info
```

---

### 3. Serve Frontend

#### Request
```
GET /
GET /dashboard.html
```

#### Response
Mengembalikan file HTML yang diminta.

#### Usage
```
Browser: http://localhost:5000
Browser: http://localhost:5000/dashboard.html
```

---

## Future API Endpoints (Planned)

### Authentication

#### Register
```
POST /api/auth/register
Content-Type: application/json

{
  "username": "john_doe",
  "password": "password123",
  "email": "john@example.com"
}

Response: 201 Created
{
  "id": "user_id",
  "username": "john_doe",
  "token": "jwt_token",
  "message": "User created successfully"
}
```

#### Login
```
POST /api/auth/login
Content-Type: application/json

{
  "username": "john_doe",
  "password": "password123"
}

Response: 200 OK
{
  "id": "user_id",
  "username": "john_doe",
  "token": "jwt_token",
  "expires_in": 86400
}
```

#### Logout
```
POST /api/auth/logout
Authorization: Bearer {token}

Response: 200 OK
{
  "message": "Logged out successfully"
}
```

---

### Income Management

#### Get Income
```
GET /api/income
Authorization: Bearer {token}
Parameters: month (YYYY-MM)

Response: 200 OK
{
  "month": "2026-06",
  "amount": 5000000,
  "emergency_fund": 500000,
  "daily_limit": 150000,
  "created_at": "2026-06-01T10:00:00Z"
}
```

#### Set Income
```
POST /api/income
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 5000000,
  "month": "2026-06"
}

Response: 201 Created
{
  "id": "income_id",
  "amount": 5000000,
  "emergency_fund": 500000,
  "daily_limit": 150000,
  "message": "Income set successfully"
}
```

#### Update Income
```
PUT /api/income/{income_id}
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 5500000
}

Response: 200 OK
{
  "id": "income_id",
  "amount": 5500000,
  "message": "Income updated successfully"
}
```

---

### Expense Management

#### Get Expenses
```
GET /api/expenses
Authorization: Bearer {token}
Parameters: month (YYYY-MM), category

Response: 200 OK
{
  "expenses": [
    {
      "id": "exp_id",
      "amount": 50000,
      "category": "makan",
      "description": "Makan siang",
      "date": "2026-06-11",
      "created_at": "2026-06-11T12:30:00Z"
    }
  ],
  "total": 150000,
  "count": 3
}
```

#### Add Expense
```
POST /api/expenses
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 50000,
  "category": "makan",
  "description": "Makan siang",
  "date": "2026-06-11"
}

Response: 201 Created
{
  "id": "exp_id",
  "amount": 50000,
  "category": "makan",
  "message": "Expense added successfully"
}
```

#### Delete Expense
```
DELETE /api/expenses/{expense_id}
Authorization: Bearer {token}

Response: 200 OK
{
  "message": "Expense deleted successfully"
}
```

#### Get Daily Total
```
GET /api/expenses/daily
Authorization: Bearer {token}
Parameters: date (YYYY-MM-DD)

Response: 200 OK
{
  "date": "2026-06-11",
  "total": 150000,
  "count": 3
}
```

---

### Savings Management

#### Get Savings Targets
```
GET /api/savings
Authorization: Bearer {token}

Response: 200 OK
{
  "savings": [
    {
      "id": "saving_id",
      "name": "Liburan Bali",
      "location": "bank",
      "target_amount": 10000000,
      "current_amount": 2000000,
      "duration_days": 90,
      "daily_amount": 111111,
      "method": "daily",
      "progress_percent": 20,
      "created_at": "2026-06-01T10:00:00Z"
    }
  ]
}
```

#### Create Savings Target
```
POST /api/savings
Authorization: Bearer {token}
Content-Type: application/json

{
  "name": "Liburan Bali",
  "location": "bank",
  "target_amount": 10000000,
  "duration_days": 90,
  "method": "daily",
  "goal": "Liburan akhir tahun"
}

Response: 201 Created
{
  "id": "saving_id",
  "name": "Liburan Bali",
  "daily_amount": 111111,
  "message": "Savings target created successfully"
}
```

#### Add Savings Transaction
```
POST /api/savings/{saving_id}/transaction
Authorization: Bearer {token}
Content-Type: application/json

{
  "amount": 500000,
  "date": "2026-06-11"
}

Response: 201 Created
{
  "id": "trans_id",
  "savings_id": "saving_id",
  "amount": 500000,
  "new_balance": 2500000,
  "progress_percent": 25,
  "message": "Transaction added successfully"
}
```

#### Delete Savings
```
DELETE /api/savings/{saving_id}
Authorization: Bearer {token}

Response: 200 OK
{
  "message": "Savings deleted successfully"
}
```

---

### Analytics

#### Get Expense Analytics
```
GET /api/analytics/expenses
Authorization: Bearer {token}
Parameters: month (YYYY-MM)

Response: 200 OK
{
  "month": "2026-06",
  "total": 500000,
  "by_category": {
    "makan": {
      "amount": 200000,
      "percent": 40,
      "count": 10
    },
    "perlengkapan": {
      "amount": 150000,
      "percent": 30,
      "count": 5
    },
    "bepergian": {
      "amount": 150000,
      "percent": 30,
      "count": 3
    }
  }
}
```

#### Get Savings Analytics
```
GET /api/analytics/savings
Authorization: Bearer {token}

Response: 200 OK
{
  "total_target": 50000000,
  "total_accumulated": 12000000,
  "overall_progress": 24,
  "targets_completed": 1,
  "targets_active": 4,
  "closest_target": {
    "id": "saving_id",
    "name": "Liburan Bali",
    "days_left": 45
  }
}
```

---

## Error Responses

### 400 Bad Request
```json
{
  "error": "Bad Request",
  "message": "Invalid input data",
  "details": "Amount must be positive"
}
```

### 401 Unauthorized
```json
{
  "error": "Unauthorized",
  "message": "Authentication required",
  "details": "Missing or invalid token"
}
```

### 403 Forbidden
```json
{
  "error": "Forbidden",
  "message": "Access denied",
  "details": "User cannot access this resource"
}
```

### 404 Not Found
```json
{
  "error": "Not Found",
  "message": "Resource not found"
}
```

### 500 Internal Server Error
```json
{
  "error": "Internal Server Error",
  "message": "An unexpected error occurred"
}
```

---

## Authentication

### Token Format
All authenticated requests require an Authorization header:
```
Authorization: Bearer {jwt_token}
```

### Token Payload (Planned)
```json
{
  "sub": "user_id",
  "username": "john_doe",
  "iat": 1623404400,
  "exp": 1623490800
}
```

---

## Rate Limiting (Planned)

### Headers
```
X-RateLimit-Limit: 100
X-RateLimit-Remaining: 95
X-RateLimit-Reset: 1623404400
```

### Limits
- 100 requests per minute per user
- 1000 requests per hour per user

---

## Data Types

### Amount (Currency)
```
Type: Integer
Unit: Rupiah (IDR)
Example: 5000000 (Rp 5.000.000)
```

### Date
```
Format: YYYY-MM-DD
Example: 2026-06-11
Timezone: Local browser timezone
```

### Category
```
Enum: "makan" | "perlengkapan" | "bepergian"
```

### Method
```
Enum: "onetime" | "daily"
```

### Location
```
Enum: "bank" | "asuransi" | "investasi" | "cash" | "other"
```

---

## Example Usage

### Using cURL

#### Get Health Status
```bash
curl -X GET http://localhost:5000/api/health
```

#### Get App Info
```bash
curl -X GET http://localhost:5000/api/info
```

### Using JavaScript (Fetch)

#### Get Health Status
```javascript
fetch('http://localhost:5000/api/health')
  .then(response => response.json())
  .then(data => console.log(data))
  .catch(error => console.error('Error:', error));
```

#### Add Expense (dengan token)
```javascript
const token = 'your_jwt_token';

fetch('http://localhost:5000/api/expenses', {
  method: 'POST',
  headers: {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  },
  body: JSON.stringify({
    amount: 50000,
    category: 'makan',
    description: 'Makan siang',
    date: '2026-06-11'
  })
})
.then(response => response.json())
.then(data => console.log(data))
.catch(error => console.error('Error:', error));
```

---

## CORS Policy

### Allowed Origins (Development)
- `http://localhost:*`
- `http://127.0.0.1:*`

### Allowed Methods
- GET
- POST
- PUT
- DELETE
- OPTIONS

### Allowed Headers
- Content-Type
- Authorization

---

## Versioning

Current API version: `v1`

Future versions:
- `v2` - Dengan database integration
- `v3` - Dengan advanced features

---

## Documentation Standards

All API responses follow this format:

```json
{
  "status": "success" | "error",
  "code": 200 | 201 | 400 | 401 | 404 | 500,
  "data": { /* response data */ },
  "message": "Human readable message",
  "timestamp": "2026-06-11T10:30:45Z"
}
```

---

## Future Improvements

- [ ] OpenAPI/Swagger documentation
- [ ] GraphQL endpoint
- [ ] WebSocket for real-time sync
- [ ] API key authentication
- [ ] OAuth2 integration
- [ ] API analytics & monitoring
- [ ] Webhook support
- [ ] Batch operations

---

**Last Updated:** Juni 2026
**API Version:** 1.0.0
**Status:** MVP (Minimal endpoints, mostly frontend-driven)
