# 🛠️ Development Environment Setup

Panduan lengkap untuk setup environment development Budget App.

---

## 📋 Prerequisites

### Sistem Operasi
- ✅ Windows 10/11
- ✅ macOS 10.14+
- ✅ Ubuntu 18.04+

### Software yang Diperlukan
- Git (optional, untuk version control)
- Python 3.7+ (WAJIB untuk backend)
- Web Browser modern
- Code Editor (VS Code recommended)

---

## 🔧 Step-by-Step Installation

### Step 1: Install Python

#### Windows
1. Download dari https://www.python.org/downloads/
2. **PENTING:** Centang "Add Python to PATH"
3. Click "Install Now"
4. Tunggu instalasi selesai

#### Verify Installation
```bash
# Open PowerShell/Command Prompt
python --version
# Expected output: Python 3.x.x

pip --version
# Expected output: pip x.x.x
```

#### macOS
```bash
# Using Homebrew (recommended)
brew install python3

# Verify
python3 --version
pip3 --version
```

#### Ubuntu/Linux
```bash
sudo apt update
sudo apt install python3 python3-pip

# Verify
python3 --version
pip3 --version
```

---

### Step 2: Install Git (Optional)

Jika ingin version control:

#### Windows
Download dari https://git-scm.com/download/win

#### macOS
```bash
brew install git
```

#### Ubuntu/Linux
```bash
sudo apt install git
```

---

### Step 3: Clone/Download Project

#### Option A: Download ZIP (Easiest)
1. Go to: https://github.com/...
2. Click "Code" → "Download ZIP"
3. Extract to folder yang diinginkan

#### Option B: Git Clone
```bash
git clone <repository-url>
cd budget-app
```

---

### Step 4: Setup Python Environment

#### Windows (PowerShell)
```bash
# Navigate to project
cd "C:\Users\LENOVO\Documents\CODING\PROKOM KELOMPOK O\budget-app\backend"

# Create virtual environment
python -m venv venv

# Activate virtual environment
.\venv\Scripts\Activate.ps1

# Install dependencies
pip install -r requirements.txt
```

#### macOS/Linux
```bash
# Navigate to project
cd ~/path-to-budget-app/backend

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

#### Verify Installation
```bash
pip list
# Should show:
# Flask 2.3.2
# flask-cors 4.0.0
# Werkzeug 2.3.6
```

---

### Step 5: Setup VS Code (Optional but Recommended)

1. Download dari https://code.visualstudio.com
2. Install
3. Open project folder: `File` → `Open Folder` → select `budget-app`
4. Install extensions:
   - Python (Microsoft)
   - Pylance
   - Live Server (untuk frontend)

---

## 🚀 Running Development Server

### Terminal 1: Backend (Flask)

#### Windows
```bash
cd backend
.\venv\Scripts\Activate.ps1
python app.py
```

#### macOS/Linux
```bash
cd backend
source venv/bin/activate
python app.py
```

**Expected Output:**
```
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://0.0.0.0:5000
WARNING in app.run
```

Leave this terminal running!

### Browser 1: Open Application

1. Open browser
2. Go to: `http://localhost:5000`
3. ✅ Aplikasi siap digunakan

---

## 📂 Project Structure Setup

```
budget-app/
├── frontend/                    # Frontend files
│   ├── index.html             # Login page
│   ├── dashboard.html         # Main app
│   └── assets/                # CSS & JS
│
├── backend/                    # Backend files
│   ├── app.py                 # Flask server
│   ├── requirements.txt        # Dependencies
│   └── venv/                  # Virtual environment (auto-created)
│
└── Documentation files
    ├── README.md
    ├── QUICKSTART.md
    └── etc
```

---

## 🔍 Troubleshooting Setup

### Problem: "python is not recognized"

**Solution:**
1. Python belum di-install
2. Python path belum di-set di environment variables
3. Restart terminal setelah install

**Fix:**
```bash
# Windows: Check if in PATH
echo %PATH%

# If not found, add manually:
# 1. Control Panel → Environment Variables
# 2. Add: C:\Users\LENOVO\AppData\Local\Programs\Python\Python311
# 3. Restart terminal
```

---

### Problem: "pip install failed"

**Solution:**
```bash
# Upgrade pip first
python -m pip install --upgrade pip

# Then try install again
pip install -r requirements.txt
```

---

### Problem: "Port 5000 already in use"

**Solution:**
```bash
# Find process using port 5000
# Windows
netstat -ano | findstr :5000

# macOS/Linux
lsof -i :5000

# Kill process
# Windows
taskkill /PID <PID> /F

# macOS/Linux
kill -9 <PID>

# Or change port in app.py line: app.run(port=8000)
```

---

### Problem: Module not found error

**Solution:**
```bash
# Make sure virtual environment is activated
# Windows
.\venv\Scripts\Activate.ps1

# macOS/Linux
source venv/bin/activate

# Should see (venv) at start of terminal

# Re-install dependencies
pip install -r requirements.txt
```

---

### Problem: CORS errors

**Solution:**
- Flask-CORS sudah configured
- Jika masih error, pastikan request dari correct origin
- Check browser console (F12) untuk detail error

---

## 🎓 Development Workflow

### Daily Development

```bash
# 1. Navigate to project
cd budget-app

# 2. Activate virtual environment
# Windows
.\backend\venv\Scripts\Activate.ps1
# macOS/Linux
source backend/venv/bin/activate

# 3. Start Flask server
cd backend
python app.py

# 4. In another terminal window, open frontend
# Simply visit http://localhost:5000

# 5. Open code editor
code .

# 6. Make changes and save (auto-reload in dev mode)

# 7. Test in browser
# F5 to refresh if needed
```

### Testing Changes

1. Make code change in editor
2. Save file
3. Flask auto-reloads (dev mode)
4. Refresh browser (F5)
5. See changes immediately

---

## 📦 Managing Dependencies

### Adding New Package

```bash
# Make sure venv activated
pip install package-name

# Update requirements.txt
pip freeze > requirements.txt
```

### Removing Package

```bash
pip uninstall package-name

# Update requirements.txt
pip freeze > requirements.txt
```

### Viewing Installed Packages

```bash
pip list

# Or check requirements
cat requirements.txt
```

---

## 🔐 Environment Variables

### Create .env file (Optional)

```bash
# backend/.env
FLASK_ENV=development
FLASK_DEBUG=True
SECRET_KEY=your-secret-key-here
DATABASE_URL=sqlite:///budget.db
```

### Load in app.py

```python
from dotenv import load_dotenv
import os

load_dotenv()

FLASK_ENV = os.getenv('FLASK_ENV', 'development')
SECRET_KEY = os.getenv('SECRET_KEY', 'dev-key')
```

---

## 🧪 Development Tips

### 1. Use Developer Tools (F12)

- **Elements**: Inspect HTML structure
- **Console**: Check JavaScript errors
- **Network**: Monitor HTTP requests
- **Storage**: View Local Storage data
- **Sources**: Debug JavaScript

### 2. Hot Reload

Flask automatically reloads pada file change dalam dev mode.

Untuk frontend:
- Install "Live Server" extension di VS Code
- Right-click file → "Open with Live Server"

### 3. Debugging with Breakpoints

```python
# In app.py
import pdb; pdb.set_trace()  # Debugger akan pause

# Or use print statements
print("Debug:", variable_name)
```

### 4. Browser Console

```javascript
// Check data in Local Storage
localStorage.getItem('budget_app_users')

// See all stored data
Object.entries(localStorage)

// Check current app instance
window.budgetApp
```

---

## 📝 Code Style Guidelines

### Python

```python
# PEP 8 style
def function_name(parameter):
    """Docstring"""
    return result

# Naming conventions
class MyClass:
    def __init__(self):
        self.attribute = value
```

### JavaScript

```javascript
// camelCase untuk variables & functions
const myVariable = "value";
function myFunction() {
    return result;
}

// PascalCase untuk classes
class MyManager {
    constructor() {}
}

// UPPER_SNAKE_CASE untuk constants
const MAX_ATTEMPTS = 3;
```

### CSS

```css
/* kebab-case untuk class names */
.my-class {
    property: value;
}

/* Use CSS variables */
:root {
    --primary-color: #2563EB;
}

.element {
    color: var(--primary-color);
}
```

---

## 🚀 Deployment Preparation

### Before Deployment

1. Deactivate debug mode
2. Update requirements.txt
3. Run tests
4. Check for console errors
5. Optimize images & assets
6. Update documentation

### Deployment Checklist

- [ ] All files committed to git
- [ ] No debug prints left
- [ ] Error handling implemented
- [ ] Logging configured
- [ ] Database migrations done
- [ ] Environment variables set
- [ ] SSL certificate ready
- [ ] Backup plan ready

---

## 🔗 Useful Resources

### Python
- https://www.python.org/
- https://flask.palletsprojects.com/
- https://pip.pypa.io/

### Frontend
- https://developer.mozilla.org/
- https://www.w3schools.com/
- https://charts.js/

### Tools
- https://code.visualstudio.com/
- https://git-scm.com/
- https://www.postman.com/

---

## 📞 Support

### Common Issues
1. Check Python version: `python --version`
2. Check pip: `pip list`
3. Check Flask: `pip show flask`
4. Reinstall all: `pip install -r requirements.txt --force-reinstall`

### Getting Help
1. Read error message carefully
2. Google the error message
3. Check GitHub issues
4. Ask on Stack Overflow
5. Contact team lead

---

**Happy Coding! 🎉**

*Last Updated: Juni 2026*
