# 💰 Budget App - Aplikasi Pengatur Uang Bulanan

Aplikasi web untuk manajemen keuangan pribadi yang membantu pengguna mengatur pengeluaran bulanan, melacak pemasukan, dan merencanakan tabungan dengan fitur dashboard interaktif.

## 🎯 Fitur Utama

### 1. **Autentikasi & Keamanan**
- ✅ Sistem login dengan username dan password
- ✅ Registrasi akun baru
- ✅ Sesi user terpisah
- ✅ Password hashing untuk keamanan dasar
- ✅ Logout yang aman

### 2. **Dashboard - Ringkasan Keuangan**
- 📊 7 Widget KPI menampilkan:
  - Total Pemasukan Bulanan
  - Uang Darurat (otomatis 10% dari pemasukan)
  - Limit Harian (otomatis (pemasukan - uang darurat) ÷ 30)
  - Total Pengeluaran Harian
  - Total Pengeluaran Bulanan
  - Sisa Uang (dengan status warna: Hijau/Kuning/Merah)
  - Status Keuangan (Aman/Hati-hati/Kritis)

### 3. **Manajemen Pemasukan**
- 💰 Input pemasukan bulanan (hanya sekali per bulan)
- 📋 Otomatis menghitung uang darurat dan limit harian
- 🔒 Uang darurat terkunci (tidak bisa diedit)

### 4. **Manajemen Pengeluaran**
- 💳 Input pengeluaran dengan kategori:
  - 🍔 Makan
  - 🛍️ Perlengkapan
  - 🚗 Bepergian
- 📝 Deskripsi optional untuk setiap pengeluaran
- 📊 Riwayat pengeluaran dengan filter kategori
- 🗑️ Hapus pengeluaran individual
- ⚠️ Alert jika pengeluaran hari ini >= limit harian

### 5. **Analisis Pengeluaran**
- 📈 Pie Chart pengeluaran per kategori
  - Warna berbeda untuk setiap kategori
  - Interactive hover & legend
  - Persentase dan nominal ditampilkan
- 📋 Breakdown pengeluaran per kategori
- 📊 Statistik pengeluaran bulanan

### 6. **Fitur Menabung**
- 🏦 Buat target tabungan dengan:
  - Nama tabungan (Liburan, Gadget, Rumah, dll)
  - Lokasi tabungan (Bank, Asuransi, Investasi, Cash, Custom)
  - Target nominal
  - Jangka waktu (hari)
  - Pilihan setoran: Sekali atau Harian Konstan
  - Tujuan optional
  
- 💾 Kalkulasi otomatis setoran harian:
  - Setoran/hari = Target ÷ Jangka Waktu
  - Contoh: Rp 10jt ÷ 90 hari = Rp 111.111/hari

- 📊 Kartu tabungan menampilkan:
  - Progress bar
  - Target vs Terkumpul
  - Setoran per hari/sekali
  - Sisa hari
  - Notifikasi saat target tercapai

- 💸 Input setoran tabungan real-time
- 📋 Riwayat setoran dengan nominal dan saldo
- 📈 Statistik tabungan keseluruhan

### 7. **Data Management**
- 🔄 Reset data fleksibel:
  - Reset pengeluaran hari ini
  - Reset pengeluaran bulan ini
  - Reset semua data
- ⚠️ Konfirmasi sebelum menghapus data
- 💾 Auto-save semua perubahan ke Local Storage

## 🗂️ Struktur Project

```
budget-app/
├── frontend/
│   ├── index.html              # Halaman login
│   ├── dashboard.html          # Halaman dashboard & savings
│   ├── assets/
│   │   ├── css/
│   │   │   └── styles.css      # Semua styling
│   │   └── js/
│   │       ├── auth.js         # Authentication logic
│   │       ├── app.js          # Main dashboard logic
│   │       ├── dashboard.js    # Module coordinator
│   │       ├── savings.js      # Savings management
│   │       └── analytics.js    # Charts & analytics
│
├── backend/
│   ├── app.py                  # Flask server
│   └── requirements.txt        # Python dependencies
│
└── README.md                   # Dokumentasi ini
```

## 🚀 Cara Menjalankan

### Prerequisites
- Python 3.7+
- Web browser modern (Chrome, Firefox, Edge, Safari)
- Tidak perlu database (menggunakan Local Storage)

### Setup & Running

#### 1. Clone/Download Project
```bash
# Jika menggunakan git
git clone <repository-url>
cd budget-app
```

#### 2. Install Dependencies (Optional, hanya untuk backend)
```bash
cd backend
pip install -r requirements.txt
```

#### 3. Jalankan Flask Backend
```bash
cd backend
python app.py
```

Server akan berjalan di `http://localhost:5000`

#### 4. Buka Aplikasi
Buka browser dan kunjungi: `http://localhost:5000`

**Atau tanpa backend**, buka file `frontend/index.html` langsung di browser.

## 📱 Cara Menggunakan

### 1️⃣ Login/Register
1. Buka aplikasi
2. Klik "Daftar di sini" untuk membuat akun baru
3. Isi username dan password (minimal 6 karakter)
4. Setelah registrasi, login dengan akun baru

### 2️⃣ Setup Pemasukan (Dashboard - Ringkasan)
1. Di bagian "Setup Pemasukan Bulanan", masukkan nominal pemasukan
2. Klik "Set Pemasukan"
3. Sistem otomatis akan menghitung:
   - Uang Darurat: 10% dari pemasukan
   - Limit Harian: (Pemasukan - Uang Darurat) ÷ 30

### 3️⃣ Input Pengeluaran (Dashboard - Pengeluaran)
1. Klik tab "💳 Pengeluaran"
2. Isi form:
   - Nominal Pengeluaran
   - Kategori (Makan/Perlengkapan/Bepergian)
   - Deskripsi (optional)
3. Klik "Tambah Pengeluaran"
4. Pengeluaran akan muncul di tabel riwayat

### 4️⃣ Lihat Analisis (Dashboard - Analisis)
1. Klik tab "📈 Analisis"
2. Lihat Pie Chart pengeluaran per kategori
3. Lihat breakdown pengeluaran dan statistik

### 5️⃣ Kelola Tabungan (Dashboard - Menabung)
1. Di dashboard, klik tombol "🏦 Kelola Menabung" atau klik tab "🏦 Menabung"
2. **Buat Target Tabungan:**
   - Isi nama tabungan
   - Pilih lokasi tabungan
   - Masukkan target nominal
   - Masukkan jangka waktu (hari)
   - Pilih metode: Sekali atau Harian
   - Klik "Buat Target Tabungan"
3. **Input Setoran:**
   - Pilih tabungan dari dropdown
   - Masukkan nominal setoran
   - Klik "Tambah Setoran"
   - Progress bar akan update otomatis

### 6️⃣ Reset Data (Dashboard - Ringkasan)
1. Klik tombol "🔄 Reset Data"
2. Pilih data yang ingin dihapus:
   - Reset Pengeluaran Hari Ini
   - Reset Pengeluaran Bulan Ini
   - Reset Semua Data
3. Klik "Hapus" dan konfirmasi

## 💾 Data Storage

- **Lokasi:** Browser Local Storage
- **Akses:** Khusus user yang login
- **Backup:** Terus tersimpan otomatis setiap ada perubahan
- **Keamanan:** Data tersimpan lokal, tidak dikirim ke server

> ⚠️ **Penting:** Jika cache browser dihapus, data akan hilang. Pertimbangkan backup regular.

## 🎨 Desain & UI

- **Responsive Design:** Bekerja optimal di desktop, tablet, mobile
- **Color Scheme:**
  - 🔵 Primary: Biru (#2563EB)
  - 🟢 Success: Hijau (#10B981)
  - 🟡 Warning: Kuning (#F59E0B)
  - 🔴 Danger: Merah (#EF4444)
- **Kategori Expense Colors:**
  - 🔴 Makan: Merah
  - 🔵 Perlengkapan: Biru
  - 🟢 Bepergian: Hijau

## 📊 Kalkulasi Otomatis

### Uang Darurat
```
Uang Darurat = Pemasukan × 10%
```

### Limit Harian
```
Limit Harian = (Pemasukan - Uang Darurat) ÷ 30
```

### Sisa Uang
```
Sisa Uang = Pemasukan - Uang Darurat - Total Pengeluaran Bulanan
```

### Status Keuangan
- 🟢 **Aman**: Sisa > 2 × Limit Harian
- 🟡 **Hati-hati**: Sisa ≤ 2 × Limit Harian
- 🔴 **Kritis**: Sisa < 0 (minus/utang)

### Setoran Tabungan Harian
```
Setoran/hari = Target Nominal ÷ Jangka Waktu (hari)
```

## 🔐 Keamanan

- ✅ Username unique
- ✅ Password minimal 6 karakter
- ✅ Password di-hash sebelum disimpan
- ✅ Session per user terpisah
- ✅ Logout menghapus session
- ✅ HTTPS recommended untuk production

## 🐛 Troubleshooting

### Aplikasi tidak bisa diakses
1. Pastikan Flask sudah running: `python app.py`
2. Cek port 5000 tidak digunakan aplikasi lain
3. Buka `http://localhost:5000` (bukan `http://127.0.0.1:5000`)

### Data tidak tersimpan
1. Pastikan Local Storage tidak disabled di browser
2. Check browser DevTools → Application → Local Storage
3. Pastikan sudah login dengan akun yang sama

### Pie Chart tidak muncul
1. Pastikan Chart.js library loaded (di dashboard.html)
2. Buka browser console untuk error messages
3. Refresh halaman

### Password lupa
1. Saat ini tidak ada recovery password
2. Solusi: Buat akun baru dengan username berbeda
3. Atau hapus localStorage dan setup ulang

## 📝 Development Notes

### Teknologi yang Digunakan
- **Frontend:** HTML5, CSS3, Vanilla JavaScript
- **Backend:** Python Flask
- **Chart:** Chart.js
- **Storage:** Browser Local Storage
- **Responsive:** CSS Media Queries

### File Structure Penting
- `auth.js`: Semua logic autentikasi
- `app.js`: Core dashboard & KPI logic
- `savings.js`: Savings management
- `analytics.js`: Chart & analytics
- `styles.css`: Semua styling (responsive)

### Menambah Fitur Baru

#### 1. Tambah Kategori Expense Baru
Edit di `dashboard.html` (kategori dropdown) dan `app.js`:
```javascript
<option value="kategori_baru">🔤 Label Kategori</option>
```

#### 2. Tambah Status Financial Baru
Edit di `app.js` method `getFinancialStatus()`:
```javascript
} else if (sisa > some_value) {
    return { label: '🔵 New Status', class: 'new-class' };
}
```

#### 3. Tambah Chart Baru
Edit di `analytics.js` method `renderChart()` atau buat method baru.

### Database Future
Jika ingin scale ke real database, persiapkan:
1. Create `/backend/models.py` dengan SQLAlchemy
2. Update `/backend/app.py` dengan API endpoints
3. Update frontend JavaScript untuk fetch data dari API
4. Deploy ke cloud: Heroku, Railway, DigitalOcean

## 📞 Support & Kontribusi

Untuk pertanyaan atau laporan bug:
1. Cek dokumentasi ini dulu
2. Check browser console untuk error messages
3. Coba refresh atau clear cache
4. Hubungi team developer

## 📄 Lisensi

Project ini dibuat untuk tujuan pembelajaran. Bebas digunakan dan dimodifikasi.

---

**Happy Budgeting! 💰✨**

*Dibuat oleh: Kelompok O - PROKOM*
*Last Updated: Juni 2026*
