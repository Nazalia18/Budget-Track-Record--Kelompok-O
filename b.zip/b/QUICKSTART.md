# 🚀 Quick Start Guide - Budget App

## ⚡ 5 Menit Setup

### Opsi 1: Buka Langsung (Termudah)
1. Navigate ke folder: `budget-app/frontend/`
2. Double-click file `index.html`
3. ✅ Aplikasi langsung terbuka di browser

**Kekurangan:** Server-related features tidak berfungsi

---

### Opsi 2: Dengan Flask Server (Recommended)

#### Step 1: Buka Terminal/PowerShell
```bash
# Windows PowerShell
# atau Command Prompt
```

#### Step 2: Navigate ke Project
```bash
cd "C:\Users\LENOVO\Documents\CODING\PROKOM KELOMPOK O\budget-app\backend"
```

#### Step 3: Install Dependencies (First Time Only)
```bash
pip install -r requirements.txt
```

Output yang diharapkan:
```
Successfully installed Flask-2.3.2 flask-cors-4.0.0 Werkzeug-2.3.6
```

#### Step 4: Jalankan Server
```bash
python app.py
```

Output yang diharapkan:
```
 * Serving Flask app 'app'
 * Debug mode: on
 * Running on http://0.0.0.0:5000
```

#### Step 5: Buka Browser
- Ketik di address bar: `http://localhost:5000`
- Tekan Enter
- ✅ Aplikasi siap digunakan!

---

## 📋 Checklist Pertama Kali

### Registrasi Akun
- [ ] Klik "Daftar di sini"
- [ ] Isi username (contoh: "john_doe")
- [ ] Isi password (minimal 6 karakter)
- [ ] Konfirmasi password
- [ ] Klik "Daftar"

### Setup Keuangan Awal
- [ ] Login dengan akun baru
- [ ] Masukkan pemasukan bulan ini (contoh: 5.000.000)
- [ ] Klik "Set Pemasukan"
- [ ] Lihat otomatis:
  - Uang Darurat: 500.000 (10%)
  - Limit Harian: 150.000
  - Status: Aman ✅

### Coba Fitur Pengeluaran
- [ ] Klik tab "💳 Pengeluaran"
- [ ] Input pengeluaran (contoh: 50.000 untuk Makan)
- [ ] Pilih kategori "Makan"
- [ ] Klik "Tambah Pengeluaran"
- [ ] Lihat di tabel riwayat

### Lihat Analytics
- [ ] Klik tab "📈 Analisis"
- [ ] Lihat Pie Chart
- [ ] Scroll bawah untuk statistik

### Coba Tabungan
- [ ] Klik "🏦 Kelola Menabung" atau tab "🏦 Menabung"
- [ ] Isi form tabungan:
  - Nama: "Liburan Bali"
  - Lokasi: "Tabungan Bank"
  - Target: 10.000.000
  - Jangka Waktu: 90
  - Metode: "Setoran Harian Konstan"
- [ ] Klik "Buat Target Tabungan"
- [ ] Input setoran (contoh: 500.000)
- [ ] Klik "Tambah Setoran"
- [ ] Lihat progress update otomatis

---

## ❌ Troubleshooting

### Error: "pip is not recognized"
**Solution:**
1. Pastikan Python sudah diinstall
2. Jika belum: Download dari https://www.python.org
3. Saat install: **Centang "Add Python to PATH"**
4. Restart terminal setelah install

### Error: "Cannot find module 'flask'"
**Solution:**
```bash
# Pastikan di folder backend
cd budget-app/backend

# Install ulang dependencies
pip install -r requirements.txt

# Atau manual install
pip install Flask==2.3.2
pip install flask-cors==4.0.0
```

### Port 5000 Sudah Terpakai
**Solution:**
1. Tutup aplikasi lain yang menggunakan port 5000
2. Atau ubah port di `backend/app.py`:
   ```python
   app.run(host='0.0.0.0', port=8000)  # Ganti 5000 jadi 8000
   ```
3. Kemudian buka: `http://localhost:8000`

### Aplikasi Tidak Bisa Diakses di `localhost:5000`
**Solution:**
1. Pastikan server masih running (lihat terminal)
2. Coba: `http://127.0.0.1:5000`
3. Atau buka URL di address bar: `http://localhost:5000`

### Data Tidak Tersimpan
**Solution:**
1. Buka DevTools (F12)
2. Tab "Application" → "Local Storage"
3. Pastikan ada entry dengan key `budget_app_*`
4. Jika kosong, berarti ada error di login

---

## 📚 Folder Structure Reference

```
budget-app/
├── frontend/
│   ├── index.html                    # Login page - BUKA INI
│   ├── dashboard.html                # Main app - BUKA SETELAH LOGIN
│   └── assets/
│       ├── css/styles.css            # Semua styling
│       └── js/
│           ├── auth.js               # Login logic
│           ├── app.js                # Dashboard logic
│           ├── dashboard.js          # Module coordinator
│           ├── savings.js            # Savings features
│           └── analytics.js          # Charts
│
├── backend/
│   ├── app.py                        # Flask server - JALANKAN INI
│   └── requirements.txt               # Python packages
│
├── README.md                         # Dokumentasi lengkap
├── QUICKSTART.md                     # File ini
└── .gitignore                        # Git configuration
```

---

## 🎮 Demo Data

Untuk testing, gunakan:

**Account 1 - Testing Reguler:**
- Username: `demo`
- Password: `demo123`

**Account 2 - Testing Savings:**
- Username: `saver`
- Password: `saver123`

*Jika sudah ada, registrasi dengan username baru*

---

## 🔄 Daily Workflow

### Setiap Pagi
1. Buka aplikasi
2. Login dengan akun Anda
3. Lihat status keuangan di dashboard
4. Cek limit harian

### Setiap Malam
1. Input pengeluaran hari ini
2. Kategori pengeluaran yang benar
3. Bisa langsung lihat sisa uang update
4. Lihat apakah sudah over budget

### Setiap Bulan
1. Masukkan pemasukan bulan baru
2. Sistem otomatis recalculate:
   - Uang darurat
   - Limit harian
3. Mulai input pengeluaran baru

### Kapan Saja
1. Lihat analytics di tab "📈 Analisis"
2. Kelola tabungan di "🏦 Menabung"
3. Download/screenshot untuk laporan

---

## 💡 Pro Tips

### Tip 1: Keamanan Password
- Gunakan password yang unik
- Jangan gunakan password email Anda
- Minimal 6 karakter (lebih banyak lebih baik)

### Tip 2: Kategori Konsisten
- Gunakan kategori yang sama untuk ease of analytics
- Contoh: "Bensin" → kategori "Bepergian", bukan "Perlengkapan"

### Tip 3: Deskripsi Berguna
- Tambahkan deskripsi yang detail
- Contoh: "Bensin Premium 10L" bukan "bensin"
- Membantu audit di bulan depan

### Tip 4: Reset Hati-hati
- Jangan klik "Reset Semua Data" sembarangan
- Lebih baik reset per hari/bulan saja
- Selalu confirm sebelum hapus

### Tip 5: Tabungan Goals
- Set target realistis
- Contoh: Liburan 1 bulan = target biasa
- Gadget premium = target 2-3 bulan

---

## 🆘 Still Need Help?

1. **Baca README.md** di folder root project
2. **Check DevTools** (F12) → Console untuk error messages
3. **Restart terminal** dan server Flask
4. **Clear cache browser** (Ctrl+Shift+Delete)
5. **Contact team developer** dengan error screenshot

---

## ✅ Status Checklist Sebelum Deploy

- [ ] Semua HTML files ada (index.html, dashboard.html)
- [ ] Semua JS files ada (auth, app, dashboard, savings, analytics)
- [ ] CSS file ada (styles.css)
- [ ] Backend files ada (app.py, requirements.txt)
- [ ] README.md & QUICKSTART.md ada
- [ ] .gitignore ada
- [ ] Test login works
- [ ] Test income setup works
- [ ] Test expense input works
- [ ] Test savings works
- [ ] Test analytics/charts works

---

**Selamat mencoba! 🎉**

*Jika ada bug atau saran, catat dan report ke team!*
