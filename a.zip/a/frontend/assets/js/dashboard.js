// dashboard.js - Dashboard Initialization & Module Coordination

document.addEventListener('DOMContentLoaded', () => {
    // Create app instance
    window.budgetApp = new BudgetApp();

    // Wait a bit for managers to initialize
    setTimeout(() => {
        // Initialize all managers with the app instance
        if (!window.savingsManager) {
            window.savingsManager = new SavingsManager(window.budgetApp);
        }
        if (!window.analyticsManager) {
            window.analyticsManager = new AnalyticsManager(window.budgetApp);
        }

        // Inject render methods into app
        window.budgetApp.renderSavingsCards = () => {
            if (window.savingsManager) window.savingsManager.renderSavingsCards();
        };

        window.budgetApp.renderSavingsSelect = () => {
            if (window.savingsManager) window.savingsManager.renderSavingsSelect();
        };

        window.budgetApp.renderTransactionTable = () => {
            if (window.savingsManager) window.savingsManager.renderTransactionTable();
        };

        window.budgetApp.renderChart = () => {
            if (window.analyticsManager) window.analyticsManager.renderChart();
        };

        window.budgetApp.renderCategoryStats = () => {
            if (window.analyticsManager) window.analyticsManager.renderCategoryStats();
        };

        window.budgetApp.renderSavingsStats = () => {
            if (window.analyticsManager) window.analyticsManager.renderSavingsStats();
        };

    }, 500);
});
