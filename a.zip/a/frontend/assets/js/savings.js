// savings.js - Savings Management Logic

class SavingsManager {
    constructor(app) {
        this.app = app;
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Savings Form
        document.getElementById('savingsForm').addEventListener('submit', (e) => this.handleSavingsSubmit(e));

        // Transaction Form
        document.getElementById('transactionForm').addEventListener('submit', (e) => this.handleTransactionSubmit(e));

        // Delete Savings Button
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('delete-savings-btn')) {
                this.deleteSavings(e.target.dataset.id);
            }
        });

        // Delete Transaction Button
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('delete-transaction-btn')) {
                this.deleteTransaction(e.target.dataset.id);
            }
        });
    }

    handleSavingsSubmit(e) {
        e.preventDefault();

        const name = document.getElementById('savingsName').value.trim();
        const location = document.getElementById('savingsLocation').value;
        const targetAmount = parseFloat(document.getElementById('targetAmount').value);
        const durationDays = parseInt(document.getElementById('durationDays').value);
        const method = document.querySelector('input[name="method"]:checked').value;
        const goal = document.getElementById('savingsGoal').value.trim();

        // Validasi
        if (!name || !location || !targetAmount || !durationDays) {
            this.app.showMessage('savingsStatus', 'Lengkapi semua field yang diperlukan!', 'error');
            return;
        }

        if (targetAmount <= 0 || durationDays <= 0) {
            this.app.showMessage('savingsStatus', 'Nilai harus lebih dari 0!', 'error');
            return;
        }

        const savingsId = Date.now();
        const dailyAmount = targetAmount / durationDays;
        const targetDate = new Date();
        targetDate.setDate(targetDate.getDate() + durationDays);

        const savings = {
            id: savingsId,
            name: name,
            location: location,
            targetAmount: targetAmount,
            currentAmount: 0,
            durationDays: durationDays,
            dailyAmount: dailyAmount,
            method: method,
            goal: goal,
            createdAt: new Date().toISOString(),
            targetDate: targetDate.toISOString(),
            transactions: []
        };

        this.app.data.savings.push(savings);
        this.app.saveData();

        this.app.showMessage('savingsStatus', 
            `✅ Target tabungan "${name}" berhasil dibuat!\n` +
            `Target: Rp ${this.app.formatCurrency(targetAmount)}\n` +
            `Setoran ${method === 'daily' ? 'Harian' : 'Sekali'}: Rp ${this.app.formatCurrency(dailyAmount)}\n` +
            `Jangka Waktu: ${durationDays} hari`, 
            'success'
        );

        document.getElementById('savingsForm').reset();
        this.renderSavingsCards();
        this.renderSavingsSelect();
    }

    handleTransactionSubmit(e) {
        e.preventDefault();

        const savingsId = parseInt(document.getElementById('savingsSelect').value);
        const amount = parseFloat(document.getElementById('transactionAmount').value);

        if (!savingsId || !amount || amount <= 0) {
            this.app.showMessage('transactionStatus', 'Pilih tabungan dan masukkan nominal!', 'error');
            return;
        }

        const savings = this.app.data.savings.find(s => s.id === savingsId);
        if (!savings) {
            this.app.showMessage('transactionStatus', 'Tabungan tidak ditemukan!', 'error');
            return;
        }

        const transaction = {
            id: Date.now(),
            amount: amount,
            date: new Date().toISOString(),
            previousBalance: savings.currentAmount
        };

        savings.currentAmount += amount;
        savings.transactions.push(transaction);

        this.app.saveData();

        this.app.showMessage('transactionStatus', 
            `✅ Setoran Rp ${this.app.formatCurrency(amount)} berhasil ditambahkan!\n` +
            `Saldo Saat Ini: Rp ${this.app.formatCurrency(savings.currentAmount)}`, 
            'success'
        );

        // Check if target reached
        if (savings.currentAmount >= savings.targetAmount) {
            alert(`🎉 Selamat! Target tabungan "${savings.name}" telah tercapai!`);
        }

        document.getElementById('transactionForm').reset();
        this.renderSavingsCards();
        this.renderTransactionTable();
    }

    deleteSavings(id) {
        const savings = this.app.data.savings.find(s => s.id === parseInt(id));
        if (!savings) return;

        if (confirm(`Hapus tabungan "${savings.name}"?`)) {
            this.app.data.savings = this.app.data.savings.filter(s => s.id !== parseInt(id));
            this.app.saveData();
            this.renderSavingsCards();
            this.renderSavingsSelect();
            this.renderTransactionTable();
        }
    }

    deleteTransaction(id) {
        const transactionId = parseInt(id);
        let found = false;

        for (let savings of this.app.data.savings) {
            const transactionIndex = savings.transactions.findIndex(t => t.id === transactionId);
            if (transactionIndex !== -1) {
                const transaction = savings.transactions[transactionIndex];
                savings.currentAmount -= transaction.amount;
                savings.transactions.splice(transactionIndex, 1);
                found = true;
                break;
            }
        }

        if (found) {
            this.app.saveData();
            this.renderTransactionTable();
            this.renderSavingsCards();
        }
    }

    renderSavingsCards() {
        const container = document.getElementById('savingsContainer');

        if (this.app.data.savings.length === 0) {
            container.innerHTML = '<div class="empty-state"><p>Belum ada target tabungan. Mulai buat target di atas!</p></div>';
            return;
        }

        container.innerHTML = this.app.data.savings.map(savings => {
            const progressPercent = (savings.currentAmount / savings.targetAmount) * 100;
            const isCompleted = savings.currentAmount >= savings.targetAmount;
            const remainingDays = Math.ceil(
                (new Date(savings.targetDate) - new Date()) / (1000 * 60 * 60 * 24)
            );
            const locationEmoji = this.getLocationEmoji(savings.location);

            return `
                <div class="savings-card">
                    <div class="savings-card-header">
                        <div>
                            <div class="savings-card-title">${savings.name}</div>
                            <div class="savings-card-location">${locationEmoji} ${this.getLocationLabel(savings.location)}</div>
                        </div>
                        <div class="savings-card-actions">
                            <button class="delete-savings-btn" data-id="${savings.id}" title="Hapus">🗑️</button>
                        </div>
                    </div>

                    <div class="savings-progress">
                        <div class="savings-progress-label">
                            <span>Progress</span>
                            <span style="color: ${isCompleted ? '#10B981' : '#6B7280'}">
                                ${Math.round(progressPercent)}%
                            </span>
                        </div>
                        <div class="progress-bar">
                            <div class="progress-fill" style="width: ${progressPercent}%; background-color: ${isCompleted ? '#10B981' : '#3B82F6'};"></div>
                        </div>
                    </div>

                    <div class="savings-details">
                        <div class="savings-detail-item">
                            <div class="savings-detail-label">Target</div>
                            <div class="savings-detail-value">Rp ${this.app.formatCurrency(savings.targetAmount)}</div>
                        </div>
                        <div class="savings-detail-item">
                            <div class="savings-detail-label">Terkumpul</div>
                            <div class="savings-detail-value">Rp ${this.app.formatCurrency(savings.currentAmount)}</div>
                        </div>
                        <div class="savings-detail-item">
                            <div class="savings-detail-label">Setoran ${savings.method === 'daily' ? 'Harian' : 'Sekali'}</div>
                            <div class="savings-detail-value">Rp ${this.app.formatCurrency(savings.dailyAmount)}</div>
                        </div>
                        <div class="savings-detail-item">
                            <div class="savings-detail-label">Sisa Hari</div>
                            <div class="savings-detail-value">${remainingDays > 0 ? remainingDays : '✅'}</div>
                        </div>
                    </div>

                    ${savings.goal ? `
                        <div style="margin-top: 1rem; padding: 0.75rem; background-color: #F0F9FF; border-radius: 0.5rem; font-size: 0.9rem;">
                            <strong>Tujuan:</strong> ${savings.goal}
                        </div>
                    ` : ''}

                    ${isCompleted ? `
                        <div style="margin-top: 1rem; padding: 0.75rem; background-color: #D1FAE5; border-radius: 0.5rem; text-align: center; color: #065F46; font-weight: 600;">
                            🎉 Target Tercapai!
                        </div>
                    ` : ''}
                </div>
            `;
        }).join('');
    }

    renderSavingsSelect() {
        const select = document.getElementById('savingsSelect');
        const currentValue = select.value;

        if (this.app.data.savings.length === 0) {
            select.innerHTML = '<option value="">-- Tidak ada tabungan --</option>';
            select.disabled = true;
            return;
        }

        select.disabled = false;
        select.innerHTML = '<option value="">-- Pilih Tabungan --</option>' + 
            this.app.data.savings.map(s => 
                `<option value="${s.id}">${s.name} (Rp ${this.app.formatCurrency(s.currentAmount)} / ${this.app.formatCurrency(s.targetAmount)})</option>`
            ).join('');

        if (currentValue) select.value = currentValue;
    }

    renderTransactionTable() {
        const tbody = document.getElementById('transactionTableBody');

        // Collect all transactions
        const allTransactions = [];
        for (let savings of this.app.data.savings) {
            for (let transaction of savings.transactions) {
                allTransactions.push({
                    ...transaction,
                    savingsName: savings.name,
                    savingsId: savings.id
                });
            }
        }

        // Sort by date descending
        allTransactions.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (allTransactions.length === 0) {
            tbody.innerHTML = '<tr class="empty-row"><td colspan="5">Belum ada setoran</td></tr>';
            return;
        }

        tbody.innerHTML = allTransactions.map(transaction => {
            const date = new Date(transaction.date).toLocaleDateString('id-ID');

            return `
                <tr>
                    <td>${date}</td>
                    <td>${transaction.savingsName}</td>
                    <td>Rp ${this.app.formatCurrency(transaction.amount)}</td>
                    <td>Rp ${this.app.formatCurrency(transaction.previousBalance + transaction.amount)}</td>
                    <td>
                        <button class="action-btn delete-transaction-btn" data-id="${transaction.id}" title="Hapus">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    getLocationEmoji(location) {
        const emojis = {
            bank: '🏦',
            asuransi: '📋',
            investasi: '📈',
            cash: '💵',
            other: '⭐'
        };
        return emojis[location] || '📌';
    }

    getLocationLabel(location) {
        const labels = {
            bank: 'Tabungan Bank',
            asuransi: 'Asuransi',
            investasi: 'Investasi Saham',
            cash: 'Cash (Brankas)',
            other: 'Lainnya'
        };
        return labels[location] || location;
    }
}

// Initialize Savings Manager when app is ready
document.addEventListener('DOMContentLoaded', () => {
    // Wait for app to be initialized
    const checkInterval = setInterval(() => {
        if (window.budgetApp) {
            clearInterval(checkInterval);
            window.savingsManager = new SavingsManager(window.budgetApp);
        }
    }, 100);
});

// Inject into BudgetApp
const originalBudgetAppInit = BudgetApp.prototype.constructor;
BudgetApp.prototype.renderSavingsCards = function() {
    if (window.savingsManager) window.savingsManager.renderSavingsCards();
};
BudgetApp.prototype.renderSavingsSelect = function() {
    if (window.savingsManager) window.savingsManager.renderSavingsSelect();
};
BudgetApp.prototype.renderTransactionTable = function() {
    if (window.savingsManager) window.savingsManager.renderTransactionTable();
};

// Make app globally accessible
document.addEventListener('DOMContentLoaded', () => {
    const checkInterval = setInterval(() => {
        const existingApp = window.budgetApp;
        if (!existingApp) {
            // App will be created by app.js
        } else {
            clearInterval(checkInterval);
        }
    }, 100);
});

// Override the placeholder method in app.js
const originalDOMContentLoaded = document.onload;
window.addEventListener('load', () => {
    // App instance should be available now
});
