// analytics.js - Analytics and Charts Logic

class AnalyticsManager {
    constructor(app) {
        this.app = app;
        this.chart = null;
    }

    renderChart() {
        const currentMonth = new Date().toISOString().slice(0, 7);
        
        // Calculate expenses by category
        const categoryData = {
            makan: 0,
            perlengkapan: 0,
            bepergian: 0
        };

        this.app.data.expenses
            .filter(e => e.date.slice(0, 7) === currentMonth)
            .forEach(e => {
                categoryData[e.category] += e.amount;
            });

        // Prepare chart data
        const labels = ['Makan', 'Perlengkapan', 'Bepergian'];
        const data = [categoryData.makan, categoryData.perlengkapan, categoryData.bepergian];
        const backgroundColor = ['#EF4444', '#3B82F6', '#10B981'];
        const borderColor = ['#DC2626', '#1E40AF', '#059669'];

        const ctx = document.getElementById('expenseChart');
        if (!ctx) return;

        // Destroy existing chart if it exists
        if (this.chart) {
            this.chart.destroy();
        }

        this.chart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: labels,
                datasets: [{
                    data: data,
                    backgroundColor: backgroundColor,
                    borderColor: borderColor,
                    borderWidth: 2,
                    hoverOffset: 10
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 15,
                            font: { size: 12, weight: '600' },
                            usePointStyle: true,
                            pointStyle: 'circle'
                        }
                    },
                    tooltip: {
                        backgroundColor: 'rgba(0, 0, 0, 0.8)',
                        padding: 12,
                        cornerRadius: 6,
                        titleFont: { size: 14, weight: 'bold' },
                        bodyFont: { size: 13 },
                        callbacks: {
                            label: (context) => {
                                const value = context.parsed;
                                const total = context.dataset.data.reduce((a, b) => a + b, 0);
                                const percentage = ((value / total) * 100).toFixed(1);
                                return `Rp ${this.app.formatCurrency(value)} (${percentage}%)`;
                            }
                        }
                    }
                }
            }
        });
    }

    renderCategoryStats() {
        const container = document.getElementById('categoryStats');
        const currentMonth = new Date().toISOString().slice(0, 7);

        // Calculate expenses by category
        const categoryData = {
            makan: { amount: 0, label: 'Makan', color: '#EF4444' },
            perlengkapan: { amount: 0, label: 'Perlengkapan', color: '#3B82F6' },
            bepergian: { amount: 0, label: 'Bepergian', color: '#10B981' }
        };

        const monthlyTotal = this.app.data.expenses
            .filter(e => e.date.slice(0, 7) === currentMonth)
            .reduce((sum, e) => {
                categoryData[e.category].amount += e.amount;
                return sum + e.amount;
            }, 0);

        if (monthlyTotal === 0) {
            container.innerHTML = '<p style="text-align: center; color: #6B7280;">Belum ada pengeluaran bulan ini</p>';
            return;
        }

        container.innerHTML = Object.entries(categoryData)
            .filter(([, data]) => data.amount > 0)
            .map(([key, data]) => {
                const percentage = ((data.amount / monthlyTotal) * 100).toFixed(1);
                return `
                    <div class="stat-item">
                        <div class="stat-label">
                            <span class="stat-color" style="background-color: ${data.color};"></span>
                            <span>${data.label}</span>
                        </div>
                        <div style="text-align: right;">
                            <div class="stat-value">Rp ${this.app.formatCurrency(data.amount)}</div>
                            <div style="font-size: 0.85rem; color: #6B7280;">${percentage}%</div>
                        </div>
                    </div>
                `;
            }).join('');
    }

    renderSavingsStats() {
        const container = document.getElementById('savingsStats');

        if (this.app.data.savings.length === 0) {
            container.innerHTML = '<p style="text-align: center; color: #6B7280; padding: 1rem;">Belum ada target tabungan</p>';
            return;
        }

        const totalTarget = this.app.data.savings.reduce((sum, s) => sum + s.targetAmount, 0);
        const totalCurrent = this.app.data.savings.reduce((sum, s) => sum + s.currentAmount, 0);
        const overallProgress = (totalCurrent / totalTarget) * 100;

        const completedSavings = this.app.data.savings.filter(s => s.currentAmount >= s.targetAmount).length;
        const activeSavings = this.app.data.savings.length - completedSavings;

        container.innerHTML = `
            <div class="savings-stat-card">
                <div class="savings-stat-label">Total Target Semua Tabungan</div>
                <div class="savings-stat-value">Rp ${this.app.formatCurrency(totalTarget)}</div>
            </div>

            <div class="savings-stat-card">
                <div class="savings-stat-label">Total Terkumpul</div>
                <div class="savings-stat-value">Rp ${this.app.formatCurrency(totalCurrent)}</div>
            </div>

            <div class="savings-stat-card">
                <div class="savings-stat-label">Progress Keseluruhan</div>
                <div style="display: flex; align-items: center; gap: 0.75rem;">
                    <div style="flex: 1; height: 8px; background-color: #F3F4F6; border-radius: 4px; overflow: hidden;">
                        <div style="width: ${overallProgress}%; height: 100%; background-color: #3B82F6; transition: width 0.3s ease;"></div>
                    </div>
                    <div class="savings-stat-value" style="font-size: 1.1rem; margin: 0;">${Math.round(overallProgress)}%</div>
                </div>
            </div>

            <div class="savings-stat-card">
                <div class="savings-stat-label">Target Tercapai</div>
                <div class="savings-stat-value">🎉 ${completedSavings}</div>
            </div>

            <div class="savings-stat-card">
                <div class="savings-stat-label">Target Aktif</div>
                <div class="savings-stat-value">🎯 ${activeSavings}</div>
            </div>

            ${this.getClosestSavings() ? `
                <div class="savings-stat-card">
                    <div class="savings-stat-label">Target Terdekat Selesai</div>
                    <div style="font-weight: 700; color: #F59E0B; margin-top: 0.5rem;">📌 ${this.getClosestSavings().name}</div>
                    <div style="font-size: 0.85rem; color: #6B7280; margin-top: 0.25rem;">
                        ${Math.ceil((this.getClosestSavings().targetAmount - this.getClosestSavings().currentAmount) / this.getClosestSavings().dailyAmount)} hari lagi
                    </div>
                </div>
            ` : ''}
        `;
    }

    getClosestSavings() {
        let closest = null;
        let minDaysLeft = Infinity;

        this.app.data.savings.forEach(savings => {
            if (savings.currentAmount < savings.targetAmount) {
                const remaining = savings.targetAmount - savings.currentAmount;
                const daysLeft = remaining / savings.dailyAmount;
                
                if (daysLeft < minDaysLeft) {
                    minDaysLeft = daysLeft;
                    closest = savings;
                }
            }
        });

        return closest;
    }

    getExpensesByDay() {
        const currentMonth = new Date().toISOString().slice(0, 7);
        const dayData = {};

        this.app.data.expenses
            .filter(e => e.date.slice(0, 7) === currentMonth)
            .forEach(e => {
                const day = e.dateOnly;
                if (!dayData[day]) dayData[day] = 0;
                dayData[day] += e.amount;
            });

        return dayData;
    }

    getMonthlyTrend() {
        const monthData = {};

        this.app.data.expenses.forEach(e => {
            const month = e.date.slice(0, 7);
            if (!monthData[month]) monthData[month] = 0;
            monthData[month] += e.amount;
        });

        return monthData;
    }
}

// Initialize Analytics Manager when app is ready
document.addEventListener('DOMContentLoaded', () => {
    const checkInterval = setInterval(() => {
        if (window.budgetApp) {
            clearInterval(checkInterval);
            window.analyticsManager = new AnalyticsManager(window.budgetApp);
        }
    }, 100);
});

// Inject into BudgetApp
BudgetApp.prototype.renderChart = function() {
    if (window.analyticsManager) window.analyticsManager.renderChart();
};

BudgetApp.prototype.renderCategoryStats = function() {
    if (window.analyticsManager) window.analyticsManager.renderCategoryStats();
};

BudgetApp.prototype.renderSavingsStats = function() {
    if (window.analyticsManager) window.analyticsManager.renderSavingsStats();
};
