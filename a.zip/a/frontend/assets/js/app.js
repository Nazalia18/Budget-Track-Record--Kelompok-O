// app.js - Main Dashboard Logic

class BudgetApp {
    constructor() {
        // Check if user is logged in
        if (!authManager.isLoggedIn()) {
            window.location.href = 'index.html';
            return;
        }

        this.username = authManager.getCurrentUsername();
        this.initializeData();
        this.setupEventListeners();
        this.updateDisplay();
    }

    initializeData() {
        const storageKey = `budget_app_${this.username}`;
        const existingData = localStorage.getItem(storageKey);

        if (!existingData) {
            this.data = {
                income: {},
                expenses: [],
                savings: []
            };
            this.saveData();
        } else {
            this.data = JSON.parse(existingData);
        }
    }

    saveData() {
        const storageKey = `budget_app_${this.username}`;
        localStorage.setItem(storageKey, JSON.stringify(this.data));
    }

    setupEventListeners() {
        // Navbar
        document.getElementById('userDisplay').textContent = this.username;
        document.getElementById('logoutBtn').addEventListener('click', () => this.logout());

        // Sidebar Navigation
        document.querySelectorAll('.nav-link').forEach(link => {
            link.addEventListener('click', (e) => this.handleNavigation(e));
        });

        // Income Form
        document.getElementById('incomeForm').addEventListener('submit', (e) => this.handleIncomeSubmit(e));

        // Expense Form
        document.getElementById('expenseForm').addEventListener('submit', (e) => this.handleExpenseSubmit(e));

        // Filter Expenses
        document.getElementById('filterCategory').addEventListener('change', () => this.renderExpenseTable());

        // Delete Expense
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('delete-expense-btn')) {
                this.deleteExpense(e.target.dataset.index);
            }
        });

        // Reset Modal
        document.getElementById('resetDataBtn').addEventListener('click', () => this.openResetModal());
        document.getElementById('closeResetModal').addEventListener('click', () => this.closeResetModal());
        document.getElementById('cancelResetBtn').addEventListener('click', () => this.closeResetModal());
        document.getElementById('confirmResetBtn').addEventListener('click', () => this.handleReset());

        // Savings Navigation
        document.getElementById('goToSavingsBtn').addEventListener('click', () => {
            this.navigateToPage('savings');
        });
    }

    handleNavigation(e) {
        e.preventDefault();
        const page = e.target.dataset.page;
        this.navigateToPage(page);
    }

    navigateToPage(page) {
        // Hide all pages
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));

        // Show selected page
        document.getElementById(page).classList.add('active');

        // Update active nav link
        document.querySelectorAll('.nav-link').forEach(link => link.classList.remove('active'));
        document.querySelector(`[data-page="${page}"]`).classList.add('active');

        // Refresh page-specific content
        if (page === 'expenses') {
            this.renderExpenseTable();
        } else if (page === 'savings') {
            this.renderSavingsCards();
            this.renderSavingsSelect();
            this.renderTransactionTable();
        } else if (page === 'analytics') {
            this.renderChart();
            this.renderCategoryStats();
            this.renderSavingsStats();
        }
    }

    handleIncomeSubmit(e) {
        e.preventDefault();

        const amount = parseFloat(document.getElementById('incomeInput').value);

        if (!amount || amount <= 0) {
            this.showMessage('incomeStatus', 'Masukkan nominal yang valid!', 'error');
            return;
        }

        const currentMonth = new Date().toISOString().slice(0, 7); // YYYY-MM

        // Check if income already set for this month
        if (this.data.income[currentMonth]) {
            this.showMessage('incomeStatus', 'Pemasukan untuk bulan ini sudah diset!', 'error');
            return;
        }

        this.data.income[currentMonth] = {
            amount: amount,
            date: new Date().toISOString()
        };

        this.saveData();

        const emergencyFund = amount * 0.1;
        const dailyLimit = (amount - emergencyFund) / 30;

        this.showMessage('incomeStatus', 
            `✅ Pemasukan berhasil disimpan!\n` +
            `Pemasukan: Rp ${this.formatCurrency(amount)}\n` +
            `Uang Darurat (10%): Rp ${this.formatCurrency(emergencyFund)}\n` +
            `Limit Harian: Rp ${this.formatCurrency(dailyLimit)}`, 
            'success'
        );

        document.getElementById('incomeForm').reset();
        this.updateDisplay();
    }

    handleExpenseSubmit(e) {
        e.preventDefault();

        const amount = parseFloat(document.getElementById('expenseAmount').value);
        const category = document.getElementById('expenseCategory').value;
        const description = document.getElementById('expenseDescription').value;

        if (!amount || amount <= 0 || !category) {
            this.showMessage('expenseStatus', 'Lengkapi semua field yang diperlukan!', 'error');
            return;
        }

        const expense = {
            id: Date.now(),
            amount: amount,
            category: category,
            description: description,
            date: new Date().toISOString(),
            dateOnly: new Date().toISOString().slice(0, 10)
        };

        this.data.expenses.push(expense);
        this.saveData();

        this.showMessage('expenseStatus', 
            `✅ Pengeluaran Rp ${this.formatCurrency(amount)} (${category}) berhasil ditambahkan!`, 
            'success'
        );

        document.getElementById('expenseForm').reset();
        this.updateDisplay();
        this.renderExpenseTable();

        // Check if over daily limit
        this.checkDailyLimit();
    }

    deleteExpense(index) {
        const expense = this.data.expenses[index];
        if (confirm(`Hapus pengeluaran Rp ${this.formatCurrency(expense.amount)}?`)) {
            this.data.expenses.splice(index, 1);
            this.saveData();
            this.updateDisplay();
            this.renderExpenseTable();
        }
    }

    openResetModal() {
        document.getElementById('resetModal').style.display = 'flex';
    }

    closeResetModal() {
        document.getElementById('resetModal').style.display = 'none';
        document.getElementById('resetToday').checked = false;
        document.getElementById('resetMonth').checked = false;
        document.getElementById('resetAll').checked = false;
    }

    handleReset() {
        const resetToday = document.getElementById('resetToday').checked;
        const resetMonth = document.getElementById('resetMonth').checked;
        const resetAll = document.getElementById('resetAll').checked;

        if (!resetToday && !resetMonth && !resetAll) {
            alert('Pilih minimal satu opsi!');
            return;
        }

        const today = new Date().toISOString().slice(0, 10);
        const currentMonth = new Date().toISOString().slice(0, 7);

        if (resetAll) {
            if (confirm('⚠️ Semua data akan dihapus permanen! Lanjutkan?')) {
                this.data = { income: {}, expenses: [], savings: [] };
                this.saveData();
                alert('Semua data berhasil dihapus!');
                this.updateDisplay();
                this.closeResetModal();
            }
        } else {
            if (resetToday) {
                this.data.expenses = this.data.expenses.filter(e => e.dateOnly !== today);
            }

            if (resetMonth) {
                this.data.expenses = this.data.expenses.filter(e => e.date.slice(0, 7) !== currentMonth);
            }

            this.saveData();
            alert('Data berhasil dihapus!');
            this.updateDisplay();
            this.renderExpenseTable();
            this.closeResetModal();
        }
    }

    renderExpenseTable() {
        const tbody = document.getElementById('expenseTableBody');
        const filterCategory = document.getElementById('filterCategory').value;

        let expenses = this.data.expenses;

        if (filterCategory) {
            expenses = expenses.filter(e => e.category === filterCategory);
        }

        // Sort by date descending
        expenses.sort((a, b) => new Date(b.date) - new Date(a.date));

        if (expenses.length === 0) {
            tbody.innerHTML = '<tr class="empty-row"><td colspan="5">Belum ada pengeluaran</td></tr>';
            return;
        }

        tbody.innerHTML = expenses.map((expense, index) => {
            const actualIndex = this.data.expenses.indexOf(expense);
            const date = new Date(expense.date).toLocaleDateString('id-ID');
            const categoryEmoji = this.getCategoryEmoji(expense.category);
            
            return `
                <tr>
                    <td>${date}</td>
                    <td>
                        <span class="category-badge ${expense.category}">
                            ${categoryEmoji} ${this.getCategoryLabel(expense.category)}
                        </span>
                    </td>
                    <td>Rp ${this.formatCurrency(expense.amount)}</td>
                    <td>${expense.description || '-'}</td>
                    <td>
                        <button class="action-btn delete-expense-btn" data-index="${actualIndex}" title="Hapus">
                            🗑️
                        </button>
                    </td>
                </tr>
            `;
        }).join('');
    }

    checkDailyLimit() {
        const income = this.getCurrentMonthIncome();
        if (!income) return;

        const emergencyFund = income * 0.1;
        const dailyLimit = (income - emergencyFund) / 30;

        const today = new Date().toISOString().slice(0, 10);
        const todayExpenses = this.data.expenses
            .filter(e => e.dateOnly === today)
            .reduce((sum, e) => sum + e.amount, 0);

        if (todayExpenses >= dailyLimit) {
            this.showMessage('expenseStatus', 
                `⚠️ Anda sudah mencapai limit harian! (Limit: Rp ${this.formatCurrency(dailyLimit)})`, 
                'error'
            );
        }
    }

    getCurrentMonthIncome() {
        const currentMonth = new Date().toISOString().slice(0, 7);
        return this.data.income[currentMonth]?.amount || null;
    }

    getCurrentMonthExpenses() {
        const currentMonth = new Date().toISOString().slice(0, 7);
        return this.data.expenses
            .filter(e => e.date.slice(0, 7) === currentMonth)
            .reduce((sum, e) => sum + e.amount, 0);
    }

    getTodayExpenses() {
        const today = new Date().toISOString().slice(0, 10);
        return this.data.expenses
            .filter(e => e.dateOnly === today)
            .reduce((sum, e) => sum + e.amount, 0);
    }

    updateDisplay() {
        const income = this.getCurrentMonthIncome();
        const monthlyExpense = this.getCurrentMonthExpenses();
        const dailyExpense = this.getTodayExpenses();

        // Update KPI Cards
        document.getElementById('totalIncome').textContent = `Rp ${this.formatCurrency(income || 0)}`;

        if (income) {
            const emergencyFund = income * 0.1;
            const dailyLimit = (income - emergencyFund) / 30;
            const sisa = income - emergencyFund - monthlyExpense;

            document.getElementById('emergencyFund').textContent = `Rp ${this.formatCurrency(emergencyFund)}`;
            document.getElementById('dailyLimit').textContent = `Rp ${this.formatCurrency(dailyLimit)}`;
            document.getElementById('remainingMoney').textContent = `Rp ${this.formatCurrency(sisa)}`;

            // Update remaining money card color
            const remainingCard = document.querySelector('.kpi-card.sisa');
            remainingCard.style.borderTopColor = this.getRemainingSisaColor(sisa, dailyLimit);

            // Update status
            const status = this.getFinancialStatus(sisa, dailyLimit);
            const statusElement = document.getElementById('financialStatus');
            statusElement.textContent = status.label;
            statusElement.className = `kpi-value status-badge ${status.class}`;
        }

        document.getElementById('dailyExpense').textContent = `Rp ${this.formatCurrency(dailyExpense)}`;
        document.getElementById('monthlyExpense').textContent = `Rp ${this.formatCurrency(monthlyExpense)}`;
    }

    getRemainingSisaColor(sisa, dailyLimit) {
        if (sisa > dailyLimit * 2) return '#10B981';
        if (sisa < 0) return '#EF4444';
        return '#06B6D4';
    }

    getFinancialStatus(sisa, dailyLimit) {
        if (sisa > dailyLimit * 2) {
            return { label: '🟢 Aman', class: 'aman' };
        } else if (sisa < 0) {
            return { label: '🔴 Kritis', class: 'kritis' };
        } else {
            return { label: '🟡 Hati-hati', class: 'hatihati' };
        }
    }

    getCategoryEmoji(category) {
        const emojis = {
            makan: '🍔',
            perlengkapan: '🛍️',
            bepergian: '🚗'
        };
        return emojis[category] || '📌';
    }

    getCategoryLabel(category) {
        const labels = {
            makan: 'Makan',
            perlengkapan: 'Perlengkapan',
            bepergian: 'Bepergian'
        };
        return labels[category] || category;
    }

    formatCurrency(amount) {
        if (!amount) return '0';
        return new Intl.NumberFormat('id-ID', {
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(amount);
    }

    showMessage(elementId, message, type = 'success') {
        const element = document.getElementById(elementId);
        element.textContent = message;
        element.className = `status-message ${type}`;
        element.style.display = 'block';

        setTimeout(() => {
            element.style.display = 'none';
        }, 5000);
    }

    logout() {
        authManager.logout();
        window.location.href = 'index.html';
    }

    // Placeholder methods untuk modul lain
    renderChart() {}
    renderCategoryStats() {}
    renderSavingsStats() {}
    renderSavingsCards() {}
    renderSavingsSelect() {}
    renderTransactionTable() {}
}

// Initialize app when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    window.budgetApp = new BudgetApp();
});
