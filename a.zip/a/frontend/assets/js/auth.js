// auth.js - Authentication Logic

class AuthManager {
    constructor() {
        this.users = this.loadUsers();
        this.currentUser = this.loadCurrentUser();
    }

    loadUsers() {
        const usersData = localStorage.getItem('budget_app_users');
        return usersData ? JSON.parse(usersData) : {};
    }

    saveUsers() {
        localStorage.setItem('budget_app_users', JSON.stringify(this.users));
    }

    loadCurrentUser() {
        const userData = localStorage.getItem('budget_app_current_user');
        return userData ? JSON.parse(userData) : null;
    }

    saveCurrentUser() {
        if (this.currentUser) {
            localStorage.setItem('budget_app_current_user', JSON.stringify(this.currentUser));
        }
    }

    register(username, password) {
        // Validasi username sudah ada
        if (this.users[username]) {
            return { success: false, message: 'Username sudah terdaftar' };
        }

        // Validasi password minimal 6 karakter
        if (password.length < 6) {
            return { success: false, message: 'Password minimal 6 karakter' };
        }

        // Hash password (simple hash untuk demo)
        const hashedPassword = this.simpleHash(password);

        // Simpan user
        this.users[username] = {
            password: hashedPassword,
            createdAt: new Date().toISOString()
        };

        this.saveUsers();
        return { success: true, message: 'Akun berhasil dibuat!' };
    }

    login(username, password) {
        // Validasi user ada
        if (!this.users[username]) {
            return { success: false, message: 'Username tidak ditemukan' };
        }

        // Validasi password
        const hashedPassword = this.simpleHash(password);
        if (this.users[username].password !== hashedPassword) {
            return { success: false, message: 'Password salah' };
        }

        // Set current user
        this.currentUser = {
            username: username,
            loginTime: new Date().toISOString()
        };

        this.saveCurrentUser();
        return { success: true, message: 'Login berhasil!' };
    }

    logout() {
        this.currentUser = null;
        localStorage.removeItem('budget_app_current_user');
    }

    isLoggedIn() {
        return this.currentUser !== null;
    }

    getCurrentUsername() {
        return this.currentUser ? this.currentUser.username : null;
    }

    simpleHash(str) {
        // Simple hash untuk demo purposes saja
        let hash = 0;
        for (let i = 0; i < str.length; i++) {
            const char = str.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash; // Convert to 32bit integer
        }
        return 'hash_' + Math.abs(hash);
    }
}

// Initialize Auth Manager
const authManager = new AuthManager();

// DOM Elements
const loginForm = document.getElementById('loginForm');
const signupLink = document.getElementById('signupLink');
const signupModal = document.getElementById('signupModal');
const signupForm = document.getElementById('signupForm');
const closeSignup = document.getElementById('closeSignup');
const errorMessage = document.getElementById('errorMessage');
const signupErrorMessage = document.getElementById('signupErrorMessage');

// Event Listeners
if (loginForm) {
    loginForm.addEventListener('submit', handleLogin);
}

if (signupLink) {
    signupLink.addEventListener('click', (e) => {
        e.preventDefault();
        signupModal.style.display = 'flex';
    });
}

if (closeSignup) {
    closeSignup.addEventListener('click', () => {
        signupModal.style.display = 'none';
        signupForm.reset();
        signupErrorMessage.style.display = 'none';
    });
}

if (signupForm) {
    signupForm.addEventListener('submit', handleSignup);
}

// Close modal when clicking outside
if (signupModal) {
    signupModal.addEventListener('click', (e) => {
        if (e.target === signupModal) {
            signupModal.style.display = 'none';
        }
    });
}

function handleLogin(e) {
    e.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value;

    // Validasi
    if (!username || !password) {
        showError('Username dan password harus diisi');
        return;
    }

    // Login
    const result = authManager.login(username, password);

    if (result.success) {
        showSuccess('Login berhasil! Redirecting...');
        setTimeout(() => {
            window.location.href = 'dashboard.html';
        }, 1500);
    } else {
        showError(result.message);
    }
}

function handleSignup(e) {
    e.preventDefault();

    const username = document.getElementById('signupUsername').value.trim();
    const password = document.getElementById('signupPassword').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    // Validasi
    if (!username || !password || !confirmPassword) {
        showSignupError('Semua field harus diisi');
        return;
    }

    if (password !== confirmPassword) {
        showSignupError('Password tidak cocok');
        return;
    }

    // Register
    const result = authManager.register(username, password);

    if (result.success) {
        showSignupSuccess(result.message);
        signupForm.reset();
        setTimeout(() => {
            signupModal.style.display = 'none';
        }, 1500);
    } else {
        showSignupError(result.message);
    }
}

function showError(message) {
    errorMessage.textContent = '❌ ' + message;
    errorMessage.style.display = 'block';
    setTimeout(() => {
        errorMessage.style.display = 'none';
    }, 5000);
}

function showSuccess(message) {
    errorMessage.innerHTML = '✅ ' + message;
    errorMessage.className = 'error-message success-message';
    errorMessage.style.display = 'block';
}

function showSignupError(message) {
    signupErrorMessage.textContent = '❌ ' + message;
    signupErrorMessage.style.display = 'block';
    setTimeout(() => {
        signupErrorMessage.style.display = 'none';
    }, 5000);
}

function showSignupSuccess(message) {
    signupErrorMessage.innerHTML = '✅ ' + message;
    signupErrorMessage.className = 'error-message success-message';
    signupErrorMessage.style.display = 'block';
}

// Check if user is logged in on page load
window.addEventListener('load', () => {
    if (document.body.classList.contains('login-page')) {
        if (authManager.isLoggedIn()) {
            // Already logged in, redirect to dashboard
            window.location.href = 'dashboard.html';
        }
    }
});
