#!/usr/bin/env python3
"""
Simple HTTP Server untuk Budget App
Tidak menggunakan Flask, hanya built-in http.server untuk compatibility dengan Python 3.14
"""

import os
import sys
from http.server import HTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
import json
from datetime import datetime

# Get frontend directory
BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BACKEND_DIR), 'frontend')

# Change to frontend directory so SimpleHTTPRequestHandler serves files correctly
os.chdir(FRONTEND_DIR)

class BudgetAppHandler(SimpleHTTPRequestHandler):
    """Custom HTTP handler for Budget App"""
    
    def end_headers(self):
        """Add CORS headers"""
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Content-Type')
        super().end_headers()
    
    def do_GET(self):
        """Handle GET requests"""
        parsed_path = urlparse(self.path)
        
        # API endpoints
        if parsed_path.path == '/api/health':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = {
                'status': 'ok',
                'timestamp': datetime.now().isoformat(),
                'app': 'Budget App'
            }
            self.wfile.write(json.dumps(response).encode())
            return
        
        if parsed_path.path == '/api/info':
            self.send_response(200)
            self.send_header('Content-Type', 'application/json')
            self.end_headers()
            response = {
                'app_name': 'Budget App',
                'version': '1.0.0',
                'features': ['Authentication', 'Income Management', 'Expense Tracking', 'Savings Targets', 'Analytics']
            }
            self.wfile.write(json.dumps(response).encode())
            return
        
        # Serve static files
        if self.path == '/':
            self.path = '/index.html'
        
        super().do_GET()
    
    def do_OPTIONS(self):
        """Handle OPTIONS requests for CORS"""
        self.send_response(200)
        self.end_headers()

def run_server(port=5000):
    """Run the server"""
    server_address = ('', port)
    httpd = HTTPServer(server_address, BudgetAppHandler)
    print(f'🚀 Budget App Server running on http://0.0.0.0:{port}')
    print(f'📂 Serving files from: {FRONTEND_DIR}')
    print(f'🌐 Open http://localhost:{port} in your browser')
    print('✋ Press Ctrl+C to stop the server')
    print('')
    
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print('\n\n👋 Server stopped.')
        sys.exit(0)

if __name__ == '__main__':
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 5000
    run_server(port)
