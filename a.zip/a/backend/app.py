from flask import Flask, render_template, jsonify, request, send_file
from flask_cors import CORS
import os
from datetime import datetime
import json

# Create app with relative paths
app = Flask(__name__)
CORS(app)

# Configure static files
BACKEND_DIR = os.path.dirname(os.path.abspath(__file__))
FRONTEND_DIR = os.path.join(os.path.dirname(BACKEND_DIR), 'frontend')

app.static_folder = FRONTEND_DIR
app.static_url_path = ''

# Routes
@app.route('/')
def index():
    return send_file(os.path.join(FRONTEND_DIR, 'index.html'))

@app.route('/dashboard.html')
def dashboard():
    return send_file(os.path.join(FRONTEND_DIR, 'dashboard.html'))

# Health check
@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'ok',
        'message': 'Budget App Server is running',
        'timestamp': datetime.now().isoformat()
    }), 200

# Info endpoint
@app.route('/api/info', methods=['GET'])
def info():
    return jsonify({
        'app_name': 'Budget App',
        'version': '1.0.0',
        'description': 'Aplikasi Pengatur Uang Bulanan',
        'features': [
            'User Authentication',
            'Income Management',
            'Expense Tracking',
            'Savings Planning',
            'Expense Analytics'
        ]
    }), 200

# Error handling
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not Found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal Server Error'}), 500

if __name__ == '__main__':
    # Development server
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True,
        use_reloader=True
    )
